import { IonPage, IonHeader, IonToolbar, IonGrid, IonRow, IonCol, IonTitle, IonIcon, IonAvatar, IonContent, IonBackButton, IonButtons, IonItem, IonLabel, IonCard } from "@ionic/react";
import { cartOutline } from "ionicons/icons";
import React from "react";

const Choose: React.FC = () => {
    return (
        <IonPage>
            <IonHeader className="mb-20px">
                <IonToolbar color="danger">
                    <IonButtons>
                        <IonBackButton className="Title" defaultHref="/home"></IonBackButton>
                        <IonTitle className="Title">Pilih Jenis Makanan</IonTitle>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonLabel className="sub-header ml-30px">Makanan Utama</IonLabel>
                <IonCard button href="/daftar/utama" className="pilih-makanan">
                    <img width="100%" src="assets/images/nasi-liwet.jpg" alt="" />
                </IonCard>
                <IonLabel className="sub-header ml-30px">Makanan Ringan</IonLabel>
                <IonCard button href="/daftar/ringan" className="pilih-makanan">
                    <img width="100%" src="assets/images/pizza.jpg" alt="" />
                </IonCard>
            </IonContent>
        </IonPage>
    )
}

export default Choose;