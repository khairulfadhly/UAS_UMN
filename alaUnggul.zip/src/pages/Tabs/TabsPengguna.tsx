import { IonApp, IonIcon, IonLabel, IonPage, IonRouterOutlet, IonTabBar, IonTabButton, IonTabs } from "@ionic/react";
import { cart, cartOutline, cashOutline, chatboxOutline, homeOutline, pencilSharp } from "ionicons/icons";
import React, { useContext, useEffect } from "react";
import { Route, Redirect } from "react-router";
import Main from "../Pengguna/Main";
import Choose from "../Pengguna/Choose";
import { IonReactRouter } from "@ionic/react-router";
import Feedback from "../Pengguna/Feedback";
import SemuaUlasan from "../Pengguna/SemuaUlasan";
import DetailPesanan from "../Pengguna/DetailPesanan";

const TabsPengguna: React.FC = () => {
    return (
        <IonPage>
            <IonApp>
                <IonReactRouter>
                    {/* <PesananContextProvider> */}
                    <IonTabs>
                        <IonRouterOutlet>
                            <Route exact path="/tabs/home" component={Main}></Route>
                            <Route exact path="/tabs/pilihjenismakanan" component={Choose}></Route>
                            <Route exact path="/tabs/feedback" component={Feedback}></Route>
                            <Route exact path="/tabs/semuaulasan" component={SemuaUlasan}></Route>
                            <Route exact path="/tabs/detailpesanan" component={DetailPesanan}></Route>
                            <Route exact path="/tabs"></Route>
                            <Redirect exact path="/home" to="/tabs/home"></Redirect>
                            <Redirect exact path="/detailpesanan" to="/tabs/detailpesanan"></Redirect>
                            <Redirect exact path="/tabs" to="/home"></Redirect>
                            <Redirect exact path="/pilihjenismakanan" to="/tabs/pilihjenismakanan"></Redirect>
                            <Redirect exact path="/feedback" to="/tabs/feedback"></Redirect>
                            <Redirect exact path="/feedback" to="/tabs/feedback"></Redirect>
                        </IonRouterOutlet>
                        <IonTabBar color="danger" slot="bottom">
                            <IonTabButton tab="home" href="/tabs/home">
                                <IonIcon icon={homeOutline}></IonIcon>
                                <IonLabel>Home</IonLabel>
                            </IonTabButton>
                            <IonTabButton tab="detailPesanan" href="/tabs/detailpesanan">
                                <IonIcon icon={cashOutline}></IonIcon>
                                <IonLabel>Detail Pesanan</IonLabel>
                            </IonTabButton>
                            <IonTabButton tab="feedback" href="/tabs/feedback">
                                <IonIcon icon={pencilSharp}></IonIcon>
                                <IonLabel>Tulis Ulasan</IonLabel>
                            </IonTabButton>
                            <IonTabButton tab="semuaUlasan" href="/tabs/semuaulasan">
                                <IonIcon icon={chatboxOutline}></IonIcon>
                                <IonLabel>Semua Ulasan</IonLabel>
                            </IonTabButton>
                        </IonTabBar>
                    </IonTabs>
                    {/* </PesananContextProvider> */}
                </IonReactRouter>
            </IonApp>
        </IonPage>
    )
}

export default TabsPengguna;