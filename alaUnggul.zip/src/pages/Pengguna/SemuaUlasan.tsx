import { getDocs, collection, getFirestore } from "@firebase/firestore";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonThumbnail,
  IonCol,
  IonGrid,
  IonRow,
  IonItem,
  IonImg,
  IonLabel,
  IonAvatar,
  IonIcon,
  IonButtons,
  IonCardSubtitle,
} from "@ionic/react";
import { cartOutline } from "ionicons/icons";
import React, { useEffect, useState } from "react";
import Header from "../../components/Header";
import firebaseConfig from "../../firebaseConfig";

const SemuaUlasan: React.FC = () => {
  const [ulasan, setUlasan] = useState<Array<any>>([]);
  const db = getFirestore(firebaseConfig);
  useEffect(() => {
    async function getData() {
      const querysnapshotUtama = await getDocs(collection(db, "ulasan"));
      console.log("QuerySnaphoot ", querysnapshotUtama);
      setUlasan(
        querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
      );
      querysnapshotUtama.forEach((doc) => {
        console.log(`${doc.id}=>${doc.data()}`);
        console.log("docs:", doc);
      });
    }
    getData();
  }, []);
  return (
    <IonPage>
      <Header title="Semua Ulasan" />
      <IonContent>
        {ulasan.map((ulasanPelanggan) => (
          <><IonItem key={ulasanPelanggan.id} lines="none">
            <IonThumbnail>
              <IonImg src={ulasanPelanggan.fotoURL}></IonImg>
            </IonThumbnail>
            <IonLabel className="ml-30px" >
              <IonLabel className="bold">{ulasanPelanggan.nama}</IonLabel>
              <IonCardSubtitle>{ulasanPelanggan.ulasan}</IonCardSubtitle>
            </IonLabel>
          </IonItem><hr /></>
        ))}
      </IonContent>
    </IonPage>
  );
};

export default SemuaUlasan;

