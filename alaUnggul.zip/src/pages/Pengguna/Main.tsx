import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonLabel,
  IonIcon,
  IonAvatar,
  IonTitle,
  IonCol,
  IonGrid,
  IonRow,
  IonContent,
  IonCard,
  IonSlide,
  IonSlides,
  IonButton,
  IonItem,
  IonButtons,
  IonToast,
  IonActionSheet,
} from "@ionic/react";
import React from "react";
import { cartOutline, star } from "ionicons/icons";
import "./pengguna.css";
import firebaseConfig from "../../firebaseConfig";
import { getFirestore, getDocs, collection, doc } from "firebase/firestore";
import { useState, useEffect } from "react";
import Login from "../Login/Login";
import { toast } from "react-toastify";
import { Bounce } from 'react-toastify';
import Header from "../../components/Header";

const Main: React.FC = () => {
  // const db = getFirestore(firebaseConfig);
  // const [daftarMakanan, setDaftarMakanan] = useState<Array<any>>([]);
  // useEffect(() => {
  //   async function getData() {
  //     const querysnapshot = await getDocs(collection(db, "daftar-makanan"));
  //     console.log("QuerySnaphoot ", querysnapshot);
  //     setDaftarMakanan(
  //       querysnapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
  //     );

  //     querysnapshot.forEach((doc) => {
  //       console.log(`${doc.id}=>${doc.data()}`);
  //       console.log("docs:", doc);
  //     });
  //   }
  //   getData();
  // }, []);


  return (
    <>
      <IonPage>
        <Header title="Resto Osteria" />
        <IonContent>
          <IonLabel className="ml-30px sub-header">Kategori Menu</IonLabel>
          <IonCard color="danger">
            <IonGrid>
              <IonRow>
                <IonCol>
                  <IonCard button href="/pilihjenismakanan">
                    <img
                      src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/Nasi%20Goreng.jpeg?alt=media&token=b2f3e409-59b2-4bd6-9843-c1ad2b8d98c4"
                      alt="masa"
                    />
                    <h6 className="ion-text-center black margin-top0 bold">
                      Makanan
                    </h6>
                  </IonCard>
                </IonCol>
                <IonCol>
                  <IonCard button href="/daftar/minuman">
                    <img src="assets/images/JUS.jpg" alt="" />
                    <h6 className="ion-text-center black margin-top0 bold">
                      Minuman
                    </h6>
                  </IonCard>
                </IonCol>
              </IonRow>
            </IonGrid>
          </IonCard>
          <br />
          <IonLabel className="ml-30px sub-header">
            Top 5 Food in Resto Osteria
          </IonLabel>
          <IonSlides className="">
            <IonSlide className="width-slide ml-30px">
              <div>
                <IonCard button href="/preview/tAqrr81RftBqOKePqPVn/utama/Nasi%20Goreng/12000/Nasi%20goreng%20adalah%20olahan%20masakan%20dengan%20menggoreng%20nasi%20dan%20diberikan%20bumbu,%20seperti%20bawang%20merah,%20bawang%20putih%20dan%20diberi%20topping%20yaitu%20telur/Nasi%20Goreng.jpeg/alt=media&token=b2f3e409-59b2-4bd6-9843-c1ad2b8d98c4" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/Nasi%20Goreng.jpeg?alt=media&token=b2f3e409-59b2-4bd6-9843-c1ad2b8d98c4"
                    alt="Top1"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Nasi Goreng</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.8
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="/preview/6S7A8UnTBZeMp6MBD6TV/utama/Nasi%20Liwet/10000/Nasi%20liwet%20adalah%20nasi%20yang%20dimasak%20dengan%20santan,%20kaldu%20ayam,%20daun%20salam%20dan%20serai,%20sehingga%20memberikan%20nasi%20rasa%20yang%20kaya,%20aromatik,%20dan%20gurih/nasi%20liwet.jpg/alt=media&token=0a927f17-ee9b-4be9-a2fa-9f3bfd923874" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/nasi%20liwet.jpg?alt=media&token=0a927f17-ee9b-4be9-a2fa-9f3bfd923874"
                    alt="Top2"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>nasi liwet</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.6
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
            <IonSlide className="width-slide ml-50px">
              <div>
                <IonCard button href="/preview/dyJn6CxGYHpDSaY88Azx/utama/sukiyaki/20000/Sukiyaki%20adalah%20irisan%20tipis%20daging%20sapi,%20sayur-sayuran,%20dan%20tahu%20di%20dalam%20panci%20besi%20yang%20dimasak%20di%20atas%20meja%20makan%20dengan%20cara%20direbus.%20Sukiyaki%20dimakan%20dengan%20mencelup%20irisan%20daging%20ke%20dalam%20kocokan%20telur%20ayam./sukiyaki.jpg/alt=media&token=7066e336-4c2e-494b-a2d3-7e0db62a3887" className="ioncard-setting-slide mt-minus">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/sukiyaki.jpg?alt=media&token=7066e336-4c2e-494b-a2d3-7e0db62a3887"
                    alt="top3"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Sukiyaki</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.5
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="/preview/0Hu90iZyZDwLV3D90veF/utama/Nasi%20Kebuli/12000/Nasi%20Kebuli%20ini%20merupakan%20menu%20makanan%20yang%20berasal%20dari%20arab%20dimana%20memadukan%20antara%20nasi,%20bumbu%20sapi%20panggang%20yang%20diberi%20topping%20daging%20sapi%20dan%20sayur%20sayuran/nasi%20kebuli.jpg/alt=media&token=8e6e221c-c0dc-45a9-a52d-57698c368ef0" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/nasi%20kebuli.jpg?alt=media&token=8e6e221c-c0dc-45a9-a52d-57698c368ef0"
                    alt="top4"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Nasi Kebuli</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.4
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="/preview/wGxYSFvIGBJKSex5Q4H5/ringan/Sosis%20Bakar/10000/Sosis%20bakar%20adalah%20makanan%20olahan%20berupa%20sosis%20yang%20dibakar%20dengan%20menggunakan%20saus%20dan%20akan%20diberi%20mayonaise/sosis%20bakar.jpg/alt=media&token=22707a17-f828-430e-9f53-53e0e01342bf" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/sosis%20bakar.jpg?alt=media&token=22707a17-f828-430e-9f53-53e0e01342bf"
                    alt="top5"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Sosis Bakar</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        3.8
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
          </IonSlides>
          <br />
          <br />
          <IonLabel className="ml-30px sub-header">
            Top 5 Drinks in Resto Osteria
          </IonLabel>
          <br></br>
          <IonSlides className="">
            <IonSlide className="width-slide ml-30px">
              <div>
                <IonCard button href="/preview/OvShKz0uYhjKfygNdI9n/minuman/coffee%20latte/5000/ini%20kopi%20starling/KopiLatejpg.jpg/alt=media&token=5b57ed34-5d5b-4ea6-a9d5-b79e93ef51a6" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/KopiLatejpg.jpg?alt=media&token=5b57ed34-5d5b-4ea6-a9d5-b79e93ef51a6"
                    alt="top1"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Coffee Latte</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.7
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="/preview/SY8Spt65M8KTXrmCE4tk/minuman/Es%20Jeruk/5000/Es%20jeruk%20merupakan%20minuman%20olahan%20dari%20jeruk%20yang%20disajikan%20dengan%20es%20batu/es%20jeruk.jpg/alt=media&token=0d6c8854-43f2-4689-8da6-d082a5096627" className="ioncard-setting-slide mt-minus">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/es jeruk.jpg?alt=media&token=0d6c8854-43f2-4689-8da6-d082a5096627"
                    alt="top2"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Es jeruk </IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.5
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
            <IonSlide className="width-slide ml-50px">
              <div>
                <IonCard button href="/preview/zNRSL2glC6horLrpuF1b/minuman/Jus%20Alpukat/8000/Jus%20alpukat%20merupakan%20minuman%20olahan%20yang%20berbahan%20dasar%20alpukat%20dan%20diberi%20susu./jus%20alpukat.jpg/alt=media&token=0efd88f0-3789-45e7-aceb-87804db8616c" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/jus alpukat.jpg?alt=media&token=0efd88f0-3789-45e7-aceb-87804db8616c"
                    alt="top3"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Jus Alpukat</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.4
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="/preview/XVpLCIfoyD6KV8ZAvaa2/minuman/Es%20Teh/4000/Es%20teh%20merupakan%20minuman%20teh%20yang%20disajikan%20dengan%20es%20batu/es%20teh.jpg/alt=media&token=5f32feb4-bc7a-485a-ad3e-0a8a0cb58111" className="ioncard-setting-slide mt-minus">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/es%20teh.jpg?alt=media&token=5f32feb4-bc7a-485a-ad3e-0a8a0cb58111"
                    alt="top4"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Es Teh</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.1
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="/preview/rym7U0NI7hWJOnoTelXE/minuman/es%20dawet/10000/ini%20minuman%20olahan%20pandan%20dengan%20gaya/EsDawet.jpg/alt=media&token=4a3370eb-d530-4969-8819-1d64b0792daa" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/EsDawet.jpg?alt=media&token=4a3370eb-d530-4969-8819-1d64b0792daa.jpg"
                    alt="top5"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Es Dawet</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        3.7
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
          </IonSlides>
        </IonContent>
      </IonPage>
    </>
  );
};

export default Main;