import { getStorage, ref } from "@firebase/storage";
import {
  IonItem,
  IonThumbnail,
  IonImg,
  IonLabel,
  IonAvatar,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonIcon,
  IonPage,
  IonRow,
  IonTitle,
  IonToolbar,
  IonBackButton,
  IonButtons,
  IonButton,
  IonItemSliding,
  IonItemOption,
  IonItemOptions,
  IonAlert,
  IonModal,
  IonInput,
} from "@ionic/react";
import { addDoc, collection, deleteDoc, Firestore, getDocs, getFirestore } from "firebase/firestore";
import {
  cartOutline,
  createOutline,
  menu,
  trashOutline,
} from "ionicons/icons";
import React, { useContext, useEffect, useRef, useState } from "react";
import PesananContext from "../../components/pesananContext";
import firebaseConfig from "../../firebaseConfig";
import { doc, updateDoc } from "@firebase/firestore";

const Keranjang: React.FC = () => {
  const pesananCTX = useContext(PesananContext);
  const storage = getStorage();
  const db = getFirestore(firebaseConfig);

  const inputJumlah = useRef<HTMLIonInputElement>(null);
  const inputPesan = useRef<HTMLIonInputElement>(null);

  const [openDelete, setOpenDelete] = useState(false);
  const [idDelete, setIdDelete] = useState("");
  const [openEdit, setOpenEdit] = useState(false);
  const [prePesanan, setPrePesanan] = useState<Array<any>>([]);

  const [selectedRow, setSelectedRow] = useState<any>();


  useEffect(() => {
    async function getData() {
      const querysnapshotUtama = await getDocs(collection(db, "keranjang"));
      console.log("QuerySnaphoot ", querysnapshotUtama);
      setPrePesanan(
        querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
      );
      querysnapshotUtama.forEach((doc) => {
        console.log(`${doc.id}=>${doc.data()}`);
        console.log("docs:", doc);
      });
    }
    getData();
  }, []);

  const addData = async () => {
    try {
      const docRef = await addDoc(collection(db, "pesanan"), {
        menu: prePesanan.map(data => data.menu),
        foto: prePesanan.map(data => data.foto),
        fotoURL: prePesanan.map(data => data.fotoURL),
        harga: prePesanan.map(data => data.hargaTotal),
        jumlah: prePesanan.map(data => data.jumlah),
        pesan: prePesanan.map(data => (data.pesan)),
      });
      console.log("Document written with ID: ", docRef.id);
      prePesanan.map(data => deleteDoc(doc(db, "keranjang", data.id)));
      window.location.href = "/detailpesanan";
    } catch (e) {
      console.error("Error adding document : ", e);
    }
  };

  const openAlertUpdate = (id: string) => {
    const row = prePesanan.find(f => f.id === id)
    setSelectedRow(row);
    setOpenEdit(true);
  }

  const updateData = async () => {
    if (!inputJumlah || !inputJumlah === null || !inputPesan || inputPesan === null) {
      return;
    }

    const newJumlah = inputJumlah.current?.value;
    const newPesan = inputPesan.current?.value;

    if (!newJumlah || !newJumlah === null) {
      return;
    }

    const jumlahInt = +newJumlah;
    const menuDoc = doc(db, "keranjang", selectedRow.id)

    const field = {
      menu: selectedRow.menu,
      foto: selectedRow.foto,
      fotoURL: selectedRow.fotoURL,
      hargaSatuan: selectedRow.hargaSatuan,
      hargaTotal: selectedRow.hargaSatuan * jumlahInt,
      jumlah: newJumlah,
      pesan: newPesan,
    }
    await updateDoc(menuDoc, field);
    setOpenEdit(false);
    window.location.href = "/keranjang";
  }

  const openAlertDelete = (id: string) => {
    const row = prePesanan.find(f => f.id === id)
    setSelectedRow(row);
    setOpenDelete(true);
  };

  const deleteData = async () => {
    const menuDoc = doc(db, 'keranjang', selectedRow.id);
    await deleteDoc(menuDoc)
    setOpenDelete(false);
    window.location.href = "/keranjang";
  }

  const closeAlertUpdate = () => {
    setOpenEdit(false);
  }

  return (
    <>
      <IonPage>

        {/* <IonAlert
          isOpen={!!openEdit}
          header="Update Data"
          buttons={[
            { text: "cancel", handler: () => setOpenEdit(false) },
            // { text: "Update", handler: () => updateData() }
          ]}
        /> */}

        <IonHeader>
          <IonToolbar color="danger">
            <IonButtons slot="start">
              <IonBackButton defaultHref="/home"></IonBackButton>
            </IonButtons>
            <IonTitle slot="start" className="Title">
              Keranjang
            </IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent>
          {prePesanan.length === 0 ? (
            <>
              <IonGrid>
                <IonRow>
                  <IonCol className="ion-text-center">
                    <IonLabel>Belum ada pesanan</IonLabel>
                  </IonCol>
                </IonRow>
                <IonRow>
                  <IonCol className="ion-text-center">
                    <IonButton href="/home">Pesan Sekarang</IonButton>
                  </IonCol>
                </IonRow>
              </IonGrid>
            </>
          ) : (
            <>
              {prePesanan.map((pesanan) => (
                <>
                  <IonAlert
                    isOpen={!!openDelete}
                    header="Confirm Action Delete"
                    message="Yakin ingin menghapus data dari daftar pesanan?"
                    buttons={[
                      { text: "Cancel", handler: () => setOpenDelete(false) },
                      { text: "Yakin", handler: () => deleteData() },
                    ]}
                  />

                  <IonModal isOpen={!!openEdit}>
                    <IonHeader>
                      <IonToolbar>
                        <IonTitle>Update Data</IonTitle>
                      </IonToolbar>
                    </IonHeader>
                    <IonContent>
                      <IonItem>
                        <IonLabel position="floating">Jumlah</IonLabel>
                        <IonInput ref={inputJumlah} value={selectedRow?.jumlah}></IonInput>
                      </IonItem>
                      <IonItem>
                        <IonLabel position="floating">Pesan</IonLabel>
                        <IonInput ref={inputPesan} value={selectedRow?.pesan}></IonInput>
                      </IonItem>
                      <IonRow className="ion-text-center">
                        <IonCol>
                          <IonButton onClick={closeAlertUpdate} color="medium">Cancel</IonButton>
                        </IonCol>
                        <IonCol>
                          <IonButton onClick={updateData} color="danger">Save</IonButton>
                        </IonCol>
                      </IonRow>
                    </IonContent>
                  </IonModal>

                  <IonItemSliding>
                    <IonItemOptions side="start">
                      <IonItemOption
                        onClick={openAlertUpdate.bind(null, pesanan.id)}
                        color="warning"
                      >
                        <IonIcon slot="icon-only" icon={createOutline}></IonIcon>
                      </IonItemOption>
                    </IonItemOptions>
                    <IonItemOptions side="end">
                      <IonItemOption
                        onClick={openAlertDelete.bind(null, pesanan.id)}
                        color="danger"
                      >
                        <IonIcon slot="icon-only" icon={trashOutline}></IonIcon>
                      </IonItemOption>
                    </IonItemOptions>
                    <IonItem key={pesanan.id}>
                      <IonThumbnail className="fix-thumbnail">
                        <IonImg
                          src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${pesanan.foto}?${pesanan.fotoURL}`}
                        ></IonImg>
                      </IonThumbnail>
                      <IonLabel className="ion-padding">
                        <h1 className="bold">{pesanan.menu}</h1>
                        <h6>QTY : {pesanan.jumlah}</h6>
                        <h6>Harga : {pesanan.hargaTotal}</h6>
                        <h6>Pesan : {pesanan.pesan}</h6>
                      </IonLabel>
                    </IonItem>
                  </IonItemSliding>
                </>
              ))}
              <br />
              <IonGrid>
                <IonRow>
                  <IonCol className="ion-text-center">
                    <IonButton color="danger" onClick={addData}>
                      Pesan Sekarang
                    </IonButton>
                  </IonCol>
                </IonRow>
                <IonRow>
                  <IonCol className="ion-text-center">
                    <IonButton color="medium">Kembali</IonButton>
                  </IonCol>
                </IonRow>
              </IonGrid>

            </>
          )}
        </IonContent>
      </IonPage>
    </>
  );
};
export default Keranjang;


