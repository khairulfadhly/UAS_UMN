import { IonPage, IonHeader, IonToolbar, IonGrid, IonRow, IonCol, IonTitle, IonIcon, IonAvatar, IonContent, IonBackButton, IonButtons, IonItem, IonLabel, IonCard, IonCardTitle } from "@ionic/react";
import { cartOutline } from "ionicons/icons";
import React from "react";
import "./Daftar.css";

const Choose: React.FC = () => {
    return (
        <IonPage>
            <IonHeader className="mb-20px">
                <IonToolbar color="danger">
                    <IonButtons>
                        <IonBackButton className="Title" defaultHref="/home"></IonBackButton>
                        <IonTitle className="Title">Pilih Jenis Makanan</IonTitle>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonRow>
                    <IonCol size="12" className="animate__animated animate__fadeIn">
                        <IonCard className="cardLong listCard" button href="/daftar/utama">
                            <IonRow>
                                <IonCol size="12">
                                    <div className="cardLongDetails chooseEdit">
                                        <IonCardTitle><strong>Makanan Utama</strong></IonCardTitle>
                                    </div>
                                </IonCol>
                                <IonCol size="12">
                                    <img src="assets/images/nasi-liwet.jpg" />
                                </IonCol>
                            </IonRow>
                        </IonCard>
                    </IonCol>
                    <IonCol size="12" className="animate__animated animate__fadeIn">
                        <IonCard className="cardLong listCard" button href="/daftar/ringan">
                            <IonRow>
                                <IonCol size="12">
                                    <div className="cardLongDetails chooseEdit">
                                        <IonCardTitle><strong>Makanan Ringan</strong></IonCardTitle>
                                    </div>
                                </IonCol>
                                <IonCol size="12">
                                    <img src="assets/images/pizza.jpg" />
                                </IonCol>
                            </IonRow>
                        </IonCard>
                    </IonCol>
                </IonRow>
            </IonContent>
        </IonPage>
    )
}

export default Choose;