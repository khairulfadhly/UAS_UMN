import {
  IonButton,
  IonCol,
  IonContent,
  IonFooter,
  IonHeader,
  IonInput,
  IonItem,
  IonLabel,
  IonPage,
  IonRow,
  IonTabBar,
  IonTabs,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { useEffect, useState } from "react";
import { toast, Bounce } from "react-toastify";
import Header from "../../components/Header";
import firebaseConfig from "../../firebaseConfig";
import "./Home.css";
import "../Pengguna/pengguna.css";

const Login: React.FC<{ cekLogin: boolean }> = (props) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [isLogined, setIisLogined] = useState(props.cekLogin);
  const [user, setUser] = useState({});

  useEffect(() => {
    firebaseConfig.auth().onAuthStateChanged(user => {
      if (user) {
        setIisLogined(true);
        return setUser(user);
      }
    });
  }, [isLogined, user]);

  const loginUser = ({ email, password }: any) => {
    firebaseConfig.auth()
      .signInWithEmailAndPassword(email, password)
      .then((res) => {
        setUser(res);
        return toast.success("Login Success!", { theme: "colored", transition: Bounce });
      })
      .catch((err) => {
        if (err.code === "auth/wrong-password") {
          return toast.error("Email or password is invalid!", { theme: "colored", transition: Bounce })
        } else if (err.code === "auth/user-not-found") {
          return toast.error("Email or password is invalid!", { theme: "colored", transition: Bounce })
        } else {
          return toast.error("Somthing went wrong!", { theme: "colored", transition: Bounce })
        }
      });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (!email || !password) {
      return toast.error("Please fill in all fields!", { theme: "colored", transition: Bounce });
    }
    const data = {
      email,
      password
    };
    loginUser(data);
  };
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="danger">
          <IonTitle>Login</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {isLogined ? (
          window.location.href = "/tabs"
        ) : (
          <form className="login" onSubmit={handleSubmit}>
            <IonRow>
              <IonCol className="form-group">
                <IonItem lines="none">
                  <input
                    type="email"
                    placeholder="Email"
                    name="email"
                    className="form-control"
                    value={email}
                    onChange={(e: any) => setEmail(e.target.value)}
                  />
                </IonItem>
              </IonCol>
            </IonRow>
            <IonRow>
              <IonCol>
                <IonItem lines="none">
                  <input
                    type="password"
                    placeholder="Password"
                    name="password"
                    className="form-control"
                    value={password}
                    onChange={(e: any) => setPassword(e.target.value)}
                  />
                </IonItem>
              </IonCol>
            </IonRow>

            <IonRow>
              <IonCol>
                <p style={{ fontSize: "small" }}>
                  By clicking LOGIN you agree to our <a href="#">Policy</a>
                </p>
                <IonButton color="danger" type="submit" expand="block">
                  Login
                </IonButton>
                <p style={{ fontSize: "medium" }}>
                  Don't have an account? <a href="/register">Sign up!</a>
                </p>
              </IonCol>
            </IonRow>
          </form>
        )
        }
      </IonContent>
      <IonFooter>
        <IonToolbar color="danger"></IonToolbar>
      </IonFooter>
    </IonPage>
  )
}
export default Login;
