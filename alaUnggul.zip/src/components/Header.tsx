import { IonActionSheet, IonAvatar, IonButtons, IonHeader, IonIcon, IonItem, IonPage, IonTitle, IonToolbar } from "@ionic/react";
import { cartOutline } from "ionicons/icons";
import React, { useState } from "react";
import { toast, Bounce } from "react-toastify";
import firebaseConfig from "../firebaseConfig";
import Login from "../pages/Login/Login";
import "../pages/Pengguna/pengguna.css";

const Header: React.FC<{ title: string }> = props => {
    const [logoutToast, setLogoutToast] = useState(false);
    const openLogoutToast = () => {
        setLogoutToast(true);
    }

    return (
        <>
            <IonActionSheet
                isOpen={!!logoutToast}
                header="Apakah anda ingin keluar?"
                buttons={[
                    {
                        text: "Keluar", handler: () =>
                            firebaseConfig.auth().signOut().then((res) => {
                                <Login cekLogin={false} />
                                window.location.href = "/"
                                return toast.success("Logout seccess", { theme: "colored", transition: Bounce });
                            }).catch((err) => {
                                return toast.error(err.message, { theme: "colored", transition: Bounce });
                            })
                    },

                    { text: "Kembali", handler: () => setLogoutToast(false) }
                ]}
            />
            <IonHeader className="mb-20px">
                <IonToolbar color="danger">
                    <IonTitle slot="start" className="Title">{props.title}</IonTitle>
                    <IonButtons slot="end">
                        <IonItem color="none" href="/keranjang">
                            <IonIcon icon={cartOutline} slot=""></IonIcon>
                        </IonItem>
                        <IonItem button onClick={openLogoutToast} color="none">
                            <IonAvatar className="image-size profile" slot="">
                                <img src="assets/images/unggul.jpg" alt="Profile" />
                            </IonAvatar>
                        </IonItem>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
        </>
    )
}
export default Header;