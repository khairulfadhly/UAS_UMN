import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonLabel,
  IonIcon,
  IonAvatar,
  IonTitle,
  IonCol,
  IonGrid,
  IonRow,
  IonContent,
  IonCard,
  IonSlide,
  IonSlides,
  IonButton,
  IonItem,
  IonButtons,
  IonToast,
  IonActionSheet,
  IonCardTitle,
} from "@ionic/react";
import React from "react";
import { cartOutline, star } from "ionicons/icons";
import "./pengguna.css";
import firebaseConfig from "../../firebaseConfig";
import { getFirestore, getDocs, collection, doc } from "firebase/firestore";
import { useState, useEffect } from "react";
import Login from "../Login/Login";
import { toast } from "react-toastify";
import { Bounce } from 'react-toastify';
import "./Daftar.css"

const Main: React.FC = () => {
  const [logoutToast, setLogoutToast] = useState(false);
  const openLogoutToast = () => {
    setLogoutToast(true);
  }

  // const db = getFirestore(firebaseConfig);
  // const [daftarMakanan, setDaftarMakanan] = useState<Array<any>>([]);
  // useEffect(() => {
  //   async function getData() {
  //     const querysnapshot = await getDocs(collection(db, "daftar-makanan"));
  //     console.log("QuerySnaphoot ", querysnapshot);
  //     setDaftarMakanan(
  //       querysnapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
  //     );

  //     querysnapshot.forEach((doc) => {
  //       console.log(`${doc.id}=>${doc.data()}`);
  //       console.log("docs:", doc);
  //     });
  //   }
  //   getData();
  // }, []);


  return (
    <>
      <IonActionSheet
        isOpen={!!logoutToast}
        header="Apakah anda ingin keluar?"
        buttons={[
          {
            text: "Keluar", handler: () =>
              firebaseConfig.auth().signOut().then((res) => {
                <Login wkkw={false} user={false} />
                window.location.href = "/"
                return toast.success("Logout seccess", { theme: "colored", transition: Bounce });
              }).catch((err) => {
                return toast.error(err.message, { theme: "colored", transition: Bounce });
              })
          },

          { text: "Kembali", handler: () => setLogoutToast(false) }
        ]}
      />
      <IonPage>
        <IonHeader>
          <IonToolbar color="danger">
            <IonTitle slot="start" className="Title">Resto Osteria</IonTitle>
            <IonButtons slot="end">
              <IonItem color="none" href="/keranjang">
                <IonIcon icon={cartOutline} slot=""></IonIcon>
              </IonItem>
              <IonItem button onClick={openLogoutToast} color="none">
                <IonAvatar className="image-size profile" slot="">
                  <img src="assets/images/unggul.jpg" alt="Profile" />
                </IonAvatar>
              </IonItem>
            </IonButtons>
          </IonToolbar>
        </IonHeader>

        <IonContent>
          <IonCard></IonCard>
          <IonLabel className="ml-30px sub-header">Kategori Menu</IonLabel>
          <IonRow>
            <IonCol size="12">
              <IonCard className="listCard" color="danger">
                <IonRow>
                  <IonCol size="6">
                    <IonCard button href="/pilihjenismakanan" className="cardLongKat listCard" color="light">
                      <IonRow>
                        <IonCol size="12">
                          <img src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/Nasi%20Goreng.jpeg?alt=media&token=b2f3e409-59b2-4bd6-9843-c1ad2b8d98c4" />
                        </IonCol>
                        <IonCol size="12">
                          <div className="cardLongDetails">
                            <p><strong>Makanan</strong></p>
                          </div>
                        </IonCol>
                      </IonRow>
                    </IonCard>
                  </IonCol>

                  <IonCol size="6" className="animate__animated animate__fadeIn">
                    <IonCard button href="/daftar/minuman" className="cardLongKat listCard" color="light">
                      <IonRow>
                        <IonCol size="12">
                          <img src="assets/images/JUS.jpg" />
                        </IonCol>
                        <IonCol size="12">
                          <div className="cardLongDetails">
                            <p><strong>Minuman</strong></p>
                          </div>
                        </IonCol>
                      </IonRow>
                    </IonCard>
                  </IonCol>
                </IonRow>
              </IonCard>
            </IonCol>
          </IonRow>
          <br />
          <IonRow>
            <IonCol>
              <h4 className="heading">Special Offers</h4>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol size="12" className="animate__animated animate__fadeIn">
              <IonCard className="cardLongSO listCard" color="light">
                <IonRow>
                  <IonCol size="4">
                    <img src="assets/images/JUS.jpg" />
                  </IonCol>
                  <IonCol size="8">
                    <div className="cardLongDetails">
                      <IonCardTitle>Beli Dapet</IonCardTitle>
                      <p>Pesanan yang di pesan, plus gratis plastik dan sedotan + sendok</p>
                    </div>
                  </IonCol>
                </IonRow>
              </IonCard>
            </IonCol>

            <IonCol size="12" className="animate__animated animate__fadeIn">
              <IonCard className="cardLongSO listCard" color="light">
                <IonRow>
                  <IonCol size="4">
                    <img src="assets/images/JUS.jpg" />
                  </IonCol>
                  <IonCol size="8">
                    <div className="cardLongDetails">
                      <IonCardTitle>Beli Dapet</IonCardTitle>
                      <p>Pesanan yang di pesan, plus gratis plastik dan sedotan + sendok</p>
                    </div>
                  </IonCol>
                </IonRow>
              </IonCard>
            </IonCol>
          </IonRow>
          <br />
          <IonLabel className="ml-30px sub-header">
            Top 5 Food in Resto Osteria
          </IonLabel>
          <IonSlides className="">
            <IonSlide className="width-slide ml-30px">
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="assets/images/Nasi-Goreng.jpeg"
                    alt="Top1"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Nasi Goreng</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.8
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="assets/images/nasi-liwet.jpg"
                    alt="Top1"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>nasi liwet</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.6
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
            <IonSlide className="width-slide ml-50px">
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/sukiyaki.jpg?alt=media&token=7066e336-4c2e-494b-a2d3-7e0db62a3887"
                    alt="media&token=7066e336-4c2e-494b-a2d3-7e0db62a3887"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Sukiyaki</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.5
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/nasi%20kebuli.jpg?alt=media&token=8e6e221c-c0dc-45a9-a52d-57698c368ef0"
                    alt="media&token=8e6e221c-c0dc-45a9-a52d-57698c368ef0"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Nasi Kebuli</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.4
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/sosis%20bakar.jpg?alt=media&token=22707a17-f828-430e-9f53-53e0e01342bf"
                    alt="media&token=22707a17-f828-430e-9f53-53e0e01342bf"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Sosis Bakar</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        3.8
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
          </IonSlides>
          <br />
          <br />
          <IonLabel className="ml-30px sub-header">
            Top 5 Drinks in Resto Osteria
          </IonLabel>
          <br></br>
          <IonSlides className="">
            <IonSlide className="width-slide ml-30px">
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/KopiLatejpg.jpg?alt=media&token=5b57ed34-5d5b-4ea6-a9d5-b79e93ef51a6"
                    alt="media&token=5b57ed34-5d5b-4ea6-a9d5-b79e93ef51a6"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Coffee Latte</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.7
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/es jeruk.jpg?alt=media&token=0d6c8854-43f2-4689-8da6-d082a5096627"
                    alt="media&token=0d6c8854-43f2-4689-8da6-d082a5096627"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Es jeruk </IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.5
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
            <IonSlide className="width-slide ml-50px">
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/jus alpukat.jpg?alt=media&token=0efd88f0-3789-45e7-aceb-87804db8616c"
                    alt="alt=media&token=0efd88f0-3789-45e7-aceb-87804db8616c"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Jus Alpukat</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.4
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/es%20teh.jpg?alt=media&token=5f32feb4-bc7a-485a-ad3e-0a8a0cb58111"
                    alt="media&token=5f32feb4-bc7a-485a-ad3e-0a8a0cb58111"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Es Teh</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        4.1
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
              <div>
                <IonCard button href="#" className="ioncard-setting-slide">
                  <img
                    className="fix-ioncard-images"
                    src="https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/EsDawet.jpg?alt=media&token=4a3370eb-d530-4969-8819-1d64b0792daa.jpg"
                    alt="media&token=4a3370eb-d530-4969-8819-1d64b0792daa.jpg"
                  />
                </IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <IonLabel>Es Dawet</IonLabel>
                    </IonCol>
                    <IonCol>
                      <IonLabel>
                        <IonIcon icon={star}></IonIcon>
                        3.7
                      </IonLabel>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </IonSlide>
          </IonSlides>
        </IonContent>
      </IonPage>
    </>
  );
};

export default Main;