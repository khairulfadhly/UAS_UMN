import {
  IonAvatar,
  IonBackButton,
  IonButtons,
  IonCard,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonIcon,
  IonImg,
  IonItem,
  IonLabel,
  IonPage,
  IonRow,
  IonText,
  IonThumbnail,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { getDocs, collection, getFirestore } from "@firebase/firestore";
import { cartOutline } from "ionicons/icons";
import React, { useEffect, useState } from "react";
import firebaseConfig from "../../firebaseConfig";

const DetailPesanan: React.FC = () => {
  const [pesanan, setPesanan] = useState<Array<any>>([]);
  const db = getFirestore(firebaseConfig);
  useEffect(() => {
    async function getData() {
      const querysnapshotUtama = await getDocs(collection(db, "pesanan"));
      console.log("QuerySnaphoot ", querysnapshotUtama);
      setPesanan(
        querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
      );
      querysnapshotUtama.forEach((doc) => {
        console.log(`${doc.id}=>${doc.data()}`);
        console.log("docs:", doc);
      });
    }
    getData();
  }, []);
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="danger">
          <IonTitle slot="start" className="Title">
            Detail Pesanan
          </IonTitle>
          <IonButtons slot="end">
            <IonItem color="none" href="/keranjang">
              <IonIcon icon={cartOutline} slot=""></IonIcon>
            </IonItem>
            <IonItem color="none">
              <IonAvatar className="image-size profile" slot="">
                <img src="assets/images/unggul.jpg" alt="Profile" />
              </IonAvatar>
            </IonItem>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {pesanan.map((pesanan) => (
          <>
            <IonCard key={pesanan.id}>
              <IonGrid>
                <IonCardTitle><b>Note</b>: {pesanan.pesan}</IonCardTitle>
                <IonRow>
                  <IonCol>
                    <IonItem lines="none">
                      <IonThumbnail>
                        <IonImg src={"https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/" + pesanan.foto + "?" + pesanan.fotoURL} />
                      </IonThumbnail>
                      <IonLabel className="ml-30px">
                        <IonText className="bold">{pesanan.menu}</IonText>
                        <IonCardSubtitle>Rp.{pesanan.harga}</IonCardSubtitle>
                      </IonLabel>
                      <IonLabel slot="end">
                        <IonLabel className="bold">Jumlah</IonLabel>
                        <IonCardSubtitle>{pesanan.jumlah}</IonCardSubtitle>
                      </IonLabel>
                    </IonItem>
                  </IonCol>
                </IonRow>
              </IonGrid>
            </IonCard>

            {/* <IonItem key={pesanan.id} lines="none">
                <IonThumbnail className="img-thumbnail margin">
                    <IonImg src={"https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/"+pesanan.foto+"?"+pesanan.fotoURL}></IonImg>
                </IonThumbnail>
                <IonLabel className="ml-30px" >
                    <IonLabel className="bold">{pesanan.pesan}</IonLabel>
                    <IonCardSubtitle>{pesanan.jumlah}</IonCardSubtitle>
                </IonLabel>
            </IonItem> */}
          </>
        ))}
      </IonContent>
    </IonPage>
  );
};

export default DetailPesanan;
