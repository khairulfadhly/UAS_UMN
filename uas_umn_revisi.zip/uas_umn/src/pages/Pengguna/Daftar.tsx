import { IonPage, IonHeader, IonToolbar, IonButtons, IonBackButton, IonTitle, IonContent, IonList, IonCard, IonLabel, IonCardSubtitle, IonCardTitle, IonCol, IonRow } from "@ionic/react";
import React from "react";
import firebaseConfig from '../../firebaseConfig'
import { getFirestore, getDocs, collection, doc } from 'firebase/firestore';
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import "./Daftar.css";

const Daftar: React.FC = () => {
    const db = getFirestore(firebaseConfig);
    const [daftarMakananUtama, setDaftarMakananUtama] = useState<Array<any>>([]);
    const [daftarMakananRingan, setDaftarMakananRingan] = useState<Array<any>>([]);
    const [daftarMinuman, setDaftarMinuman] = useState<Array<any>>([]);

    const jenis = useParams<{ jenis: string }>().jenis;

    useEffect(() => {
        async function getData() {
            const querysnapshotUtama = await getDocs(collection(db, "daftar-makanan"));
            const querySnapshotRingan = await getDocs(collection(db, "daftar-makanan-ringan"));
            const querySnapshotminuman = await getDocs(collection(db, "daftar-minuman"));
            console.log('QuerySnaphoot ', querysnapshotUtama);
            setDaftarMakananUtama(querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            setDaftarMakananRingan(querySnapshotRingan.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            setDaftarMinuman(querySnapshotminuman.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            querysnapshotUtama.forEach((doc) => {
                console.log(`${doc.id}=>${doc.data()}`);
                console.log('docs:', doc);
            });
        }
        getData();

    }, []);
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar color="danger">
                    <IonButtons>
                        <IonBackButton className="Title" defaultHref={jenis === 'utama' || 'ringan' ? "/pilihjenismakanan" : '/home'} ></IonBackButton>
                        <IonTitle className="Title">{jenis === 'utama' ? 'Daftar Makanan Utama' : jenis === 'ringan' ? 'Daftar Makanan Ringan' : "Daftar Minuman"}</IonTitle>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen color="light">
            <IonRow>
                <IonCard></IonCard>
            </IonRow>
            <IonRow>
                {jenis == 'utama' ? daftarMakananUtama.map(makanan => (
                        <IonCol size="6">
                            <IonCard button className="listCard" href={`/preview/${makanan.id}/${jenis}/${makanan.nama}/${makanan.harga}/${makanan.deskripsi}/${makanan.foto}/${makanan.fotoURL}`}>
                                <img src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${makanan.foto}?${makanan.fotoURL}`} alt={makanan.title} />
                                <IonCardTitle>{makanan.nama}</IonCardTitle>
                                <IonCardSubtitle><i>Makanan Utama</i></IonCardSubtitle>
                                <div className="listPrice">
                                    <h4>Rp.{makanan.harga}</h4>
                                </div>
                            </IonCard>
                        </IonCol>
                )) : jenis == 'ringan' ? daftarMakananRingan.map(makanan => (
                    <IonCol size="6">
                    <IonCard button className="listCard" href={`/preview/${makanan.id}/${jenis}/${makanan.nama}/${makanan.harga}/${makanan.deskripsi}/${makanan.foto}/${makanan.fotoURL}`}>
                        <img src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${makanan.foto}?${makanan.fotoURL}`} alt={makanan.title} />
                        <IonCardTitle>{makanan.nama}</IonCardTitle>
                        <IonCardSubtitle><i>Makanan Ringan</i></IonCardSubtitle>
                        <div className="listPrice">
                            <h4>Rp.{makanan.harga}</h4>
                        </div>
                    </IonCard>
                </IonCol>
                )) : daftarMinuman.map(minuman => (
                    // <IonCard button href={`/preview/${minuman.id}/${jenis}/${minuman.nama}/${minuman.harga}/${minuman.deskripsi}/${minuman.foto}/${minuman.fotoURL}`} className="pilih-makanan">
                    //     <img className="absolute" width="100%" src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${minuman.foto}?${minuman.fotoURL}`} alt={minuman.title} />
                    //     <IonLabel color="light" className="absolute top-card sub-header ml-10px">{minuman.nama}</IonLabel>
                    // </IonCard>
                    <IonCol size="6">
                    <IonCard button className="listCard" href={`/preview/${minuman.id}/${jenis}/${minuman.nama}/${minuman.harga}/${minuman.deskripsi}/${minuman.foto}/${minuman.fotoURL}`}>
                        <img src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${minuman.foto}?${minuman.fotoURL}`} alt={minuman.title} />
                        <IonCardTitle>{minuman.nama}</IonCardTitle>
                        <IonCardSubtitle><i>Minuman</i></IonCardSubtitle>
                        <div className="listPrice">
                            <h4>Rp.{minuman.harga}</h4>
                        </div>
                    </IonCard>
                </IonCol>
                ))
                }
                </IonRow>
            </IonContent>
        </IonPage>
    )
}

export default Daftar;